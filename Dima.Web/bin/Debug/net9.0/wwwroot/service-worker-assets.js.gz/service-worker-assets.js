self.assetsManifest = {
  "version": "bJkRzA5+",
  "assets": [
    {
      "hash": "sha256-kJXKqRCleT/Jk1wJUhUu24r2LAA7IWVYmdoENizE38M=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-2gItJ0j/o5RSWg7VYqCOBpSPI1dxTOG+mnEzWt7EvYw=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-lz0Xidl9yw53lEeYs4XMU39zSRQzpCIyWOQSAG0/0GU=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-aMWXTEYWKe3h8JlrC7e+t3MOsEQQhp/UkL0RrWGxziY=",
      "url": "_framework/Dima.Core.02pn4y5vmz.pdb"
    },
    {
      "hash": "sha256-wF7nK0t5qGpnDCXnra0igKi/a/ogfGBs1X7Ckw55gi4=",
      "url": "_framework/Dima.Core.8ucbh25op7.wasm"
    },
    {
      "hash": "sha256-lc4p9pZlSYZ6kIxXLaGz0JYLB9LhaI6tsEpUQFlJEoc=",
      "url": "_framework/Dima.Web.1tsvvreyy4.pdb"
    },
    {
      "hash": "sha256-hPIVsFW9p6XYtHkQ8vT+8QYyBvzUL/Od5u/h5mTJYoA=",
      "url": "_framework/Dima.Web.csc7lzryfr.wasm"
    },
    {
      "hash": "sha256-N6/4dp+rtuEu+iWs7ZZs30QrZzpGpF9KC6ulCWZCo2w=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.n41ua9ceve.wasm"
    },
    {
      "hash": "sha256-NwK8BjzpX6xFk8D/LqoC1QI9czCiuLd6J/zqGJwdP78=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.vum2aqzk55.wasm"
    },
    {
      "hash": "sha256-AZJqGXJM2Sos31wIr7syLy0TWCLYEWzemxDkwUyfPyk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.9at76jd5um.wasm"
    },
    {
      "hash": "sha256-0GsGHUcZqMbcNzsilO3GcgG7962qJ/ZHuKufQPUcbh4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gczxzkllks.wasm"
    },
    {
      "hash": "sha256-KwD9Lhu5DlaqdB2ceYX2LavpwSIAS5H07ZPT2jVbiu4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.5cygu8f0zf.wasm"
    },
    {
      "hash": "sha256-LC8EOVC037PLK7kiBBjTc4OgSJmE8IaSiBmv1uPpWSc=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.Authentication.syfcl4vhll.wasm"
    },
    {
      "hash": "sha256-AYyXG0WrvwNEEX2QtbpR9AtYu26WKG+S10Q398vbgqY=",
      "url": "_framework/Microsoft.AspNetCore.Components.h4ild4sjod.wasm"
    },
    {
      "hash": "sha256-4cwypYnAi4rj5KOaa6JhniDEFacv1aXC85uiheBnFzE=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.f0dx7f7ser.wasm"
    },
    {
      "hash": "sha256-QJKG5agfskYhNg4CWMzF8EqwsNALoPtT7h5pO9k6aHk=",
      "url": "_framework/Microsoft.CSharp.0krj4ve566.wasm"
    },
    {
      "hash": "sha256-jDyhCV8cQbTPnpBqglv4yrebO3dwcGR9Qxr3jDN3TiE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.4wniagvoij.wasm"
    },
    {
      "hash": "sha256-/BVr1LLZIYqgXdQ90iUr1/D2t3vcprltsUruXsJ0cfg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.oft8zow1u0.wasm"
    },
    {
      "hash": "sha256-zJFN2zPVrAdlNGE4KvSGiLAHA104ztoLn0uUA3H1qhE=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.42czujeagm.wasm"
    },
    {
      "hash": "sha256-5TvpNHL/IqovZnXYmUxCSVWMgft6GMyuSEDiinnaGUI=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.5osbqvurog.wasm"
    },
    {
      "hash": "sha256-3TPUsnMMwttXgftVgbXhX0+ZG+UHYp0RAzg60SK4Xfk=",
      "url": "_framework/Microsoft.Extensions.Configuration.h7p166i5j0.wasm"
    },
    {
      "hash": "sha256-6QiZ6ttmBzkOYTrIhx5vn32K1RnFzuIj2hQ1vU9Z2SI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.1u3eeol6ve.wasm"
    },
    {
      "hash": "sha256-535Ri4bDpwShlFxqaB7dD5Yl2+IgEZg9lvbdZA/lyw4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.tjpnkvn3q9.wasm"
    },
    {
      "hash": "sha256-rzJCBPH8DpfKdGPn17EiQIYzFF+ka4D3mxc637CetBw=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.p6uikc63bw.wasm"
    },
    {
      "hash": "sha256-I6sT+1LjsFgzXn9V8VE5qJid109lRHIC1zvMl0JziyE=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.zw8wqvwieu.wasm"
    },
    {
      "hash": "sha256-/FsPVHT/gqsYED9DQNPCtnqnJ6AEIo1Zo8wglXIiji0=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.4ewk3ipqll.wasm"
    },
    {
      "hash": "sha256-CppJFrBtxPacr6ynl4+uMj6BHjjS6mGJH5dxN9PVxeY=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.qnaw45f7ij.wasm"
    },
    {
      "hash": "sha256-rn1kOaNzJs0PQXRilQjYtvfwBN43zrliuDrnW/NL7n8=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.q5if44af42.wasm"
    },
    {
      "hash": "sha256-ml9sf7n/EnF6OuwUx8cjvPVk8Yqo96V7rBV5awQKI9o=",
      "url": "_framework/Microsoft.Extensions.Http.asiqinrfj2.wasm"
    },
    {
      "hash": "sha256-/cbKro/iHTt02hewrByb6oqdeUsxxfFAyRKKr7GpBNI=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.5map5kd04b.wasm"
    },
    {
      "hash": "sha256-hcJFVGS1x8m5ZeBhvyIEBqYSQKIzBLnbw77jq3TNVmA=",
      "url": "_framework/Microsoft.Extensions.Localization.nx0z2f3xfv.wasm"
    },
    {
      "hash": "sha256-HL4q4QdxykEypsK6yHSuKFDnFazCabrP4+wPtq0DGLw=",
      "url": "_framework/Microsoft.Extensions.Logging.4m4jo20ji4.wasm"
    },
    {
      "hash": "sha256-1LlcwgP4uVIn3ZSnDyj7sHNFtk4bzbDVotS012VUwh4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4483uwth6m.wasm"
    },
    {
      "hash": "sha256-GQupnD6TPDjIfuVUrK+ECik/CCFIlDNutVnMnWGrRrQ=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.fanky0at9h.wasm"
    },
    {
      "hash": "sha256-ISvQeTODuLxU6ohxJBLyLb4qQ2JoQRUQitBOE9577Ps=",
      "url": "_framework/Microsoft.Extensions.Options.hse9gm9r95.wasm"
    },
    {
      "hash": "sha256-OdxJw7jdILDZ3gOpGiCsOP1rr13RNw5EjKRvXzmr5Lg=",
      "url": "_framework/Microsoft.Extensions.Primitives.3pkwbmnqmy.wasm"
    },
    {
      "hash": "sha256-kSwbIGuYmzrEilFXnLY8mKBXXFQtVXKAF/Qa323+Fnk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.fkdz83fr0b.wasm"
    },
    {
      "hash": "sha256-wG2lM2idoDLOwqFHD84hv6SbaH0Yt59g1BsijrC8V1U=",
      "url": "_framework/Microsoft.JSInterop.gkumi7kxvo.wasm"
    },
    {
      "hash": "sha256-Raj1ha4M/EXL7zvyW9Evn28B9GxWHE0gaLR/NXPSrdk=",
      "url": "_framework/Microsoft.VisualBasic.Core.bcw8auwqwc.wasm"
    },
    {
      "hash": "sha256-Wn1A97sEio88/HfvTRdDM1pgRek6RfaNgVkwzSIvIAw=",
      "url": "_framework/Microsoft.VisualBasic.ezua2clavb.wasm"
    },
    {
      "hash": "sha256-fpruv6j/oxW6ShRcvC3R4IzPnm84DB6isAtNqeHrgoU=",
      "url": "_framework/Microsoft.Win32.Primitives.2w82csd6tr.wasm"
    },
    {
      "hash": "sha256-sMbuu2+9aoI7Hg1VxqD7awy9/80c7+mSA2IpQJ9cIiw=",
      "url": "_framework/Microsoft.Win32.Registry.krtg4e9rjb.wasm"
    },
    {
      "hash": "sha256-74cGeJMX9xiSEe4+ufSsWPNCtw3wdr+1zSRTSmv1VWc=",
      "url": "_framework/MudBlazor.xcgdsu1w4u.wasm"
    },
    {
      "hash": "sha256-wC6hefX/ulHEGaUYIqCLBwi7gA6hQNb0Wx8qMIV9z6s=",
      "url": "_framework/System.AppContext.ch56s52ual.wasm"
    },
    {
      "hash": "sha256-MY+U3ZlBY/4EXlPMdmcAcxpQ3PtuXA/QTcWMig4lBE4=",
      "url": "_framework/System.Buffers.tlm3i6pt76.wasm"
    },
    {
      "hash": "sha256-zNxb6Q2yWey9J5o05rp5/XN2BJbkCWxs9fMZt2D9QY8=",
      "url": "_framework/System.Collections.0loryrgbgz.wasm"
    },
    {
      "hash": "sha256-S34voGnBqYhqsh0kGAp9FGIPyRaYbwLbZnsMN94DxMQ=",
      "url": "_framework/System.Collections.Concurrent.jadgrn67lq.wasm"
    },
    {
      "hash": "sha256-R00latuvi3TzXKtyvI9Rq5n4jVFNbUQZq9lDQxMOIZY=",
      "url": "_framework/System.Collections.Immutable.9o9b1v73b4.wasm"
    },
    {
      "hash": "sha256-W1J4Nps6QP0Xd6+4fg8OERkjgk5aEPSkmvymvC2uHK8=",
      "url": "_framework/System.Collections.NonGeneric.3azrjxh966.wasm"
    },
    {
      "hash": "sha256-tQgQQ+/98VQfR8IGhcUhRrLTDaGfRA9fq7q/gouJUHs=",
      "url": "_framework/System.Collections.Specialized.pf8o02gi88.wasm"
    },
    {
      "hash": "sha256-A8/UlZ7726XTgBgUyeC2Bdqfj7cEw9Q6wkYX87lBc/w=",
      "url": "_framework/System.ComponentModel.1bvu7o7kso.wasm"
    },
    {
      "hash": "sha256-MEYu5tDNKAyvFF+LYTBPSN61MqizjOuE3FsQ62umVng=",
      "url": "_framework/System.ComponentModel.Annotations.ws0vg1jr4x.wasm"
    },
    {
      "hash": "sha256-ofRm47QJlEEj5/ditS6lJ/OFwN9GPd1orZrbk3184bY=",
      "url": "_framework/System.ComponentModel.DataAnnotations.dtsracnza3.wasm"
    },
    {
      "hash": "sha256-U3Mo8M3CzQRvY1qREaldjhXT4mKqxSEu8EHVu32yOQk=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.ra9xq384hx.wasm"
    },
    {
      "hash": "sha256-iA+b3OlObFpC0/Aif4wF6FSDtWOiEGsjHrpeZHYxOLY=",
      "url": "_framework/System.ComponentModel.Primitives.crjaxnx0st.wasm"
    },
    {
      "hash": "sha256-lbIwcqLYoaa5SNCjZPiTD8JT2JDAxgEIg0wVPo5FGf0=",
      "url": "_framework/System.ComponentModel.TypeConverter.z2oi73nl5l.wasm"
    },
    {
      "hash": "sha256-2w+W5e16+eBXhrOFFjDsiXmq54potpxISbp6U39bXAg=",
      "url": "_framework/System.Configuration.bcycfuj8pt.wasm"
    },
    {
      "hash": "sha256-QFSBCNk38q9aia7gARK8J/s1qkjRLWL/6CT+sepwTqY=",
      "url": "_framework/System.Console.w0ay1b4srp.wasm"
    },
    {
      "hash": "sha256-kcBybtj6CRk/fZvUnhTfjCPRJJWLJEuJJOZ+Yo8sLzU=",
      "url": "_framework/System.Core.hclyk32q51.wasm"
    },
    {
      "hash": "sha256-rDRPheqL0Y21f5bnN9z2/ttDPiYdxaaBxm0T0+PGHFM=",
      "url": "_framework/System.Data.8fnvbemkr6.wasm"
    },
    {
      "hash": "sha256-bQIenRafLaZWCon1qGPGOM4AkcfxOPUdBGuc5yrU9OA=",
      "url": "_framework/System.Data.Common.h7ixcjvq7n.wasm"
    },
    {
      "hash": "sha256-EiFxhIvAU86+kjjC6zLjLzNtl6+HquG/e2sKmB5YEHA=",
      "url": "_framework/System.Data.DataSetExtensions.27v8nihu4b.wasm"
    },
    {
      "hash": "sha256-bMz8wdeh6qh0Glsbnk9sqPBfIPz5R4Kx2n1t5fcfU08=",
      "url": "_framework/System.Diagnostics.Contracts.g37ic7xnxa.wasm"
    },
    {
      "hash": "sha256-sFy2+QBSQ1Hv4v3MgMWtpwuVqX0DPbTSM1HXp6FTjZo=",
      "url": "_framework/System.Diagnostics.Debug.cdnw9jdjr1.wasm"
    },
    {
      "hash": "sha256-BevUJO0S3Y7mVFaDzJsZ6eThyn0kC8HY1o3AHcarVFA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.3u89chdpwh.wasm"
    },
    {
      "hash": "sha256-gyGwoikjkAiRgOI79D9hrIfd5uJd7BDpQywb6stIQss=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.t8k8uawqmh.wasm"
    },
    {
      "hash": "sha256-/WQOeNwiRZiB86yHRrZqlmypYYJdcdzSvwSoLmNx+Oc=",
      "url": "_framework/System.Diagnostics.Process.nbu219jctg.wasm"
    },
    {
      "hash": "sha256-ExBa8DBK+IdPS6NcH/lR/EAeaPfjrGBdQaXgztPBKro=",
      "url": "_framework/System.Diagnostics.StackTrace.7f3f9acuyj.wasm"
    },
    {
      "hash": "sha256-a2hGEFZU4f3NY4AUor7hcjqxo2Kx2/xI2E3q/U3v89o=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.l8i9ben6g9.wasm"
    },
    {
      "hash": "sha256-BH1joZ5+NtBBPjrdr9kdXEySXjW3Yf+nQXS9sDWrMrM=",
      "url": "_framework/System.Diagnostics.Tools.su3q70cfjw.wasm"
    },
    {
      "hash": "sha256-cwFQXPENSGEB+XqxrrY7aDhsiFbS5BQ0TtGymIc6ubg=",
      "url": "_framework/System.Diagnostics.TraceSource.777sathwzn.wasm"
    },
    {
      "hash": "sha256-1qN0Q19TU45x/Im/t4R53BL6+iDetXv9BiK7uiI7K34=",
      "url": "_framework/System.Diagnostics.Tracing.qrb1u99ma2.wasm"
    },
    {
      "hash": "sha256-W7QQ6nE401Cz/DrtlEuOFnBu4MLcnIN48U/DOOUMPsY=",
      "url": "_framework/System.Drawing.5kh3shl062.wasm"
    },
    {
      "hash": "sha256-qNXMrmUu8VWriCVAjd4x99fJMlmg88PISG5YV9QHnPI=",
      "url": "_framework/System.Drawing.Primitives.wesyyx6itb.wasm"
    },
    {
      "hash": "sha256-s3Np2Puug4kgzoloDG0Das0RYCSUra8Dk+JuizZMNrw=",
      "url": "_framework/System.Dynamic.Runtime.zwh4o2uogo.wasm"
    },
    {
      "hash": "sha256-zOnjJI1BdX4xmiKvyb21glt7AlFwkyUpq2gjut26icU=",
      "url": "_framework/System.Formats.Asn1.sw73ne3kde.wasm"
    },
    {
      "hash": "sha256-kmIHH4nVicnYxBYQZxYcdf7Ts0e5MloHhlPGP0UTpF8=",
      "url": "_framework/System.Formats.Tar.ucentu0i1k.wasm"
    },
    {
      "hash": "sha256-uKcSR3IsbhlAmzUnOF8LoElE2AeDReUBqz7BT2j3i70=",
      "url": "_framework/System.Globalization.Calendars.wyl6b2gjv4.wasm"
    },
    {
      "hash": "sha256-iP8NezkN9pmUNO1m9fKv3XKdVd8dgqU5p7y8WXotrwI=",
      "url": "_framework/System.Globalization.Extensions.0at1e69ufq.wasm"
    },
    {
      "hash": "sha256-CmeYNP9tuEG8lzVcNAHnM0+pTDrPAEYaSW+UQnn7F0s=",
      "url": "_framework/System.Globalization.ea4xp7l2s8.wasm"
    },
    {
      "hash": "sha256-jBFM3N9fksCOsjJXa2ixhMgtpFpLsCoXaw2a2/5brH0=",
      "url": "_framework/System.IO.Compression.Brotli.4wfk96u424.wasm"
    },
    {
      "hash": "sha256-0Ww+n6u93HyjYEWEMJ9aK2XxqOUq7uAD0+C4VYvuP28=",
      "url": "_framework/System.IO.Compression.FileSystem.fga5z7h1wd.wasm"
    },
    {
      "hash": "sha256-mLtyFapE4sUoJ/7ppXE4Bap82l73KMQ4PLDvByk7WQA=",
      "url": "_framework/System.IO.Compression.ZipFile.kp8u44q6bl.wasm"
    },
    {
      "hash": "sha256-NWa/ooYeUbpjpI2vsZbyHIrQO+Q1bQBf4uI43t9LtV4=",
      "url": "_framework/System.IO.Compression.l063hh1m4m.wasm"
    },
    {
      "hash": "sha256-OM1a5nybzW5KJpJqWX40wqJVB1KXez2NHBwgy6181BI=",
      "url": "_framework/System.IO.FileSystem.AccessControl.gqo8i3yxtl.wasm"
    },
    {
      "hash": "sha256-QblxSOTsuEI65Dkn4KTsQ7Khcvt/vQstRLWH6jfeclI=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.1o666npdpl.wasm"
    },
    {
      "hash": "sha256-re/SYMTA3qOu0RU9/HZDNtDec+d2XzSAhk4l2VynKWI=",
      "url": "_framework/System.IO.FileSystem.Primitives.7j619s2u6b.wasm"
    },
    {
      "hash": "sha256-nqEW6A4CLNfm8yFpxPPoKxvy13Wm4PZjg09+SYzKlqA=",
      "url": "_framework/System.IO.FileSystem.Watcher.i0dqersjke.wasm"
    },
    {
      "hash": "sha256-NdJ+m1FPeukY0vhVF03iHZ8N4bfgDbGr6HcSW5IAtQQ=",
      "url": "_framework/System.IO.FileSystem.xd0pof1l0v.wasm"
    },
    {
      "hash": "sha256-MDpYXnYgTfAMlIi7P7dfB/HgtPEgsWeBIH72oaM5cFM=",
      "url": "_framework/System.IO.IsolatedStorage.86d2nxz30o.wasm"
    },
    {
      "hash": "sha256-bz2InjhxjJys3ql0UjqFJeGPj+Q20QBmYUVZwxNIC1U=",
      "url": "_framework/System.IO.MemoryMappedFiles.hwg4cmnexd.wasm"
    },
    {
      "hash": "sha256-mUhfk0EQo9xhQLG/6XzqLuCAj9BRsxwm0joy8t/pytc=",
      "url": "_framework/System.IO.Pipelines.hyk2aqc7g8.wasm"
    },
    {
      "hash": "sha256-VNK7ZAjEIuB4YolSq9QjtSMFnSedfh8Yu7fNjgervOg=",
      "url": "_framework/System.IO.Pipes.AccessControl.8jmdzj76k5.wasm"
    },
    {
      "hash": "sha256-Ogq9G2wgekC3/9PZg9C2vJNBxsVe88Ea+QNCDGDixGU=",
      "url": "_framework/System.IO.Pipes.itag36er3p.wasm"
    },
    {
      "hash": "sha256-Rc23C5bFm+NvhiYFb2F/JjnhLFVSER+Ebj/kNmY1zRA=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.xl34mv7373.wasm"
    },
    {
      "hash": "sha256-etjJtLeCDXgtTRWot03cMUjMbkzONxqD+7Rpu16Mc9w=",
      "url": "_framework/System.IO.a8lovankol.wasm"
    },
    {
      "hash": "sha256-t5Hx6teTiN+ss+MSc5UsLtUwusl0e5T8Lv+YwF6OOjc=",
      "url": "_framework/System.Linq.982cs7cwl7.wasm"
    },
    {
      "hash": "sha256-TCZ/AZRZm9MkZ9CRDzReCZbB85ijJmjxt5Pzb2GIJhY=",
      "url": "_framework/System.Linq.Expressions.keojcyx7rh.wasm"
    },
    {
      "hash": "sha256-0UxGkKXobQy7ybzPDsnLHKomY/CCVdUyKz4MI2+PT1w=",
      "url": "_framework/System.Linq.Parallel.rt0wj1di9x.wasm"
    },
    {
      "hash": "sha256-J2Blxrg/WYao64RgUe4cap1lRDM8fJnBJi5vEkw7b7w=",
      "url": "_framework/System.Linq.Queryable.xmuj2bfl3h.wasm"
    },
    {
      "hash": "sha256-WmXCKPUHRXCk0NlBi7iFCKUV1GLvpdRos4N6EMmHeNo=",
      "url": "_framework/System.Memory.e21pxyo7f6.wasm"
    },
    {
      "hash": "sha256-Ir1YjR5eIiNstQ14NSwsMO+GjAAiPYcFadrDElTMXNk=",
      "url": "_framework/System.Net.Http.67y0knk64j.wasm"
    },
    {
      "hash": "sha256-dSSvmKzciY92FqsRlD04+cQ1/xJwR1wlCMsNwG2Irik=",
      "url": "_framework/System.Net.Http.Json.158hlj0e3x.wasm"
    },
    {
      "hash": "sha256-+v7c/NCAqhai/cqsi10INRyfL56wed+scAI4jUZ1L3k=",
      "url": "_framework/System.Net.HttpListener.6kj06u2myw.wasm"
    },
    {
      "hash": "sha256-zHyOFCZxXJzndlJY1B0lS4nInYkm/tvKFbcsiv+wK5w=",
      "url": "_framework/System.Net.Mail.of8mvgjv93.wasm"
    },
    {
      "hash": "sha256-tOv/V4XH5WxxREP6fBXdKcukomwgzvv/08ookA7C8qM=",
      "url": "_framework/System.Net.NameResolution.ojvc5fs9x8.wasm"
    },
    {
      "hash": "sha256-1RIK76qrAuN9Ls8QzpMjvFlZckmyeZjDOo8NwvkLMXM=",
      "url": "_framework/System.Net.NetworkInformation.h55ndb6w9r.wasm"
    },
    {
      "hash": "sha256-XdueAWf5/NGXPXSAjHI8Brqw7V3jOzsoyePO8aGv6Ls=",
      "url": "_framework/System.Net.Ping.f5i7hfw2qc.wasm"
    },
    {
      "hash": "sha256-42JPWogxvNPLq4quzArZWkG/QsqUWWm86Cj4C4D1sa8=",
      "url": "_framework/System.Net.Primitives.ppkhii4grn.wasm"
    },
    {
      "hash": "sha256-QkEPh3PvrI4dPDLIpgTygLkFTcEVkrTUCZNEsX+w9JU=",
      "url": "_framework/System.Net.Quic.6n4jzsrw88.wasm"
    },
    {
      "hash": "sha256-rJcamXzNO1ekGh8RWXMtOh+N8AAGY4aWd8SEibSO+N0=",
      "url": "_framework/System.Net.Requests.cy4h9bs3pl.wasm"
    },
    {
      "hash": "sha256-7pBbQ3JNwdsbpSCe64kP6y5J3WNLl0geBY2nyCObfE8=",
      "url": "_framework/System.Net.Security.ibdm0dxxqk.wasm"
    },
    {
      "hash": "sha256-m5RH4cT0q+UB9jZ3rXwBoaHGOGdAKuuSmSSWCEErWgs=",
      "url": "_framework/System.Net.ServicePoint.fb4vl6a7xv.wasm"
    },
    {
      "hash": "sha256-4loqakg4OHudAmPhC2qqNk5yivAJgeY4olQhpTDuIdM=",
      "url": "_framework/System.Net.Sockets.in1jyhlij3.wasm"
    },
    {
      "hash": "sha256-37mgTGMpzPm8MccRDW6zSigCf8aCYtmng8w3m6opE/Y=",
      "url": "_framework/System.Net.WebClient.pe57fwwtmc.wasm"
    },
    {
      "hash": "sha256-cI0IR9id1UGuk7V/GiCcwz4NTh6H4x5ZCjMWoOdUf5I=",
      "url": "_framework/System.Net.WebHeaderCollection.8q2vnfgdag.wasm"
    },
    {
      "hash": "sha256-hY5FTAGWLF1e594jinkACgApEoPmkwd4DlvtQnFrv7I=",
      "url": "_framework/System.Net.WebProxy.dy3uj3cuhy.wasm"
    },
    {
      "hash": "sha256-gU7BySBDk/czIunWAoDJBBn1lQEstVT2CLFWqGVdXBg=",
      "url": "_framework/System.Net.WebSockets.Client.5n8jkuhz18.wasm"
    },
    {
      "hash": "sha256-8hEFPzMud0UFQVWGQri3oLxzgxxPYWdymB7jf0vzF3k=",
      "url": "_framework/System.Net.WebSockets.eth3pjb0i0.wasm"
    },
    {
      "hash": "sha256-9qq9GGIui5WYuj05+rEWDETzM2PLIJrQ0e8eGDnsgd4=",
      "url": "_framework/System.Net.uvxuq9ftj8.wasm"
    },
    {
      "hash": "sha256-wR1QIPtgAB4/lGcKQgFudx5l4L1TCTTOIcAJxjagJoU=",
      "url": "_framework/System.Numerics.Vectors.xwm370m73u.wasm"
    },
    {
      "hash": "sha256-bPuY4jEgjX3yU5McFGiZOwlVGH/KLTKlzE5egxmkdtE=",
      "url": "_framework/System.Numerics.sa5zv0szr0.wasm"
    },
    {
      "hash": "sha256-+TUb+XSkf4I8OhmpoNR9TyRK+HIr3rRAdgA/hGUh4rk=",
      "url": "_framework/System.ObjectModel.55syvdebib.wasm"
    },
    {
      "hash": "sha256-iqXECPj8uFcb/7OzD0dDXV+C8VvMmS7RYZ6ZUnFdlTs=",
      "url": "_framework/System.Private.CoreLib.u3k7k03qne.wasm"
    },
    {
      "hash": "sha256-cxf7wW1ItVLs9wxdXgkCVuE9ixVZ/7F0GD3aJLGc5Y0=",
      "url": "_framework/System.Private.DataContractSerialization.h3lzbevrhq.wasm"
    },
    {
      "hash": "sha256-u8os5WkllHqDK95zgG7EL7Gcn5aNNmwVgt0HuritLgM=",
      "url": "_framework/System.Private.Uri.h9vk2avn0v.wasm"
    },
    {
      "hash": "sha256-0Zkg5yF1TaIbfyQVhVERiYqSyHwjjLkiyxuzf71HwHM=",
      "url": "_framework/System.Private.Xml.9m32bkuaq9.wasm"
    },
    {
      "hash": "sha256-49bEelPi/IOYMUy6ONqfW30KBK9PQeFtzie1HtJkEz4=",
      "url": "_framework/System.Private.Xml.Linq.x7s9isnak8.wasm"
    },
    {
      "hash": "sha256-d47g6JYxmJyoiBxLTpcVwvykP3iI1cG55cNoIOhrQPI=",
      "url": "_framework/System.Reflection.DispatchProxy.1mvitd31h1.wasm"
    },
    {
      "hash": "sha256-qhWoKLKLRFAAu8x/U9eNzZEjZKk2Qo+7T1bDwP0alZg=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.6hwdc9qxly.wasm"
    },
    {
      "hash": "sha256-LQW1zV195d2m2wOfYbSJ0DMYK4vyxjcY7GZvkfTQ08M=",
      "url": "_framework/System.Reflection.Emit.Lightweight.reku4tedat.wasm"
    },
    {
      "hash": "sha256-WiFnjtq0lMc+LqArnFe5Pf/Xc1+uPIp2O22ycbMtKh0=",
      "url": "_framework/System.Reflection.Emit.ejqw77rpzl.wasm"
    },
    {
      "hash": "sha256-6vkCMdZvArRCmUTWE/d8xZTJnT8/EG3IM1x6Ibpm+uA=",
      "url": "_framework/System.Reflection.Extensions.6pmkengf2g.wasm"
    },
    {
      "hash": "sha256-s48s0oTM6p3Cp1rRbepFrVrllW+oHLFbHr0tYswY1fw=",
      "url": "_framework/System.Reflection.Metadata.17tmzwz2au.wasm"
    },
    {
      "hash": "sha256-09+fcB0s+D8FmQr7mLAg8gl/gcPw7qz6z0sKHL/iQps=",
      "url": "_framework/System.Reflection.Primitives.b2osjpgeyo.wasm"
    },
    {
      "hash": "sha256-voyi3UjdlBq1uElH8sHEdXshHHrh9rq880LpLm5t9q4=",
      "url": "_framework/System.Reflection.TypeExtensions.elsa09wwcc.wasm"
    },
    {
      "hash": "sha256-YMbJmh96SPHMqeN13OGN7rFSgYknRzHfsSuE2Scycb8=",
      "url": "_framework/System.Reflection.wo2kjrze7x.wasm"
    },
    {
      "hash": "sha256-/Kpn9QoktmfrUJcoDIzXwjKv+yH2+lpfa9sxRWli4ew=",
      "url": "_framework/System.Resources.Reader.09wnmnw7h6.wasm"
    },
    {
      "hash": "sha256-f1qtSs4oIK7eVKXX2ZkgTj5GqfLYi3TXoND29mZ1Y/4=",
      "url": "_framework/System.Resources.ResourceManager.9uorrdaogh.wasm"
    },
    {
      "hash": "sha256-LHsRXI9207NVVm81YPLmiNikIYYiXzPSw45X8MueLaY=",
      "url": "_framework/System.Resources.Writer.4ao90ee7f8.wasm"
    },
    {
      "hash": "sha256-X4iXiK7XlfaL9/oRaMNEwOyFW5APbQ0jyE8f5cpeqoo=",
      "url": "_framework/System.Runtime.9idl43ts3r.wasm"
    },
    {
      "hash": "sha256-xnAgqgTwMzqhQSv0tUTOYBz0X3JxqXOCoH+vRZU4RE4=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.mtlbkuc7bx.wasm"
    },
    {
      "hash": "sha256-NUOuqO8WgcXpNt4/3SNHvGr+z2wb030WyafdjI7vsHM=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.ropftsemtf.wasm"
    },
    {
      "hash": "sha256-WPYOiQCm1/mKP5sZU8AZTdRAnv2AXLw8Xt2BolVzot4=",
      "url": "_framework/System.Runtime.Extensions.849myor78y.wasm"
    },
    {
      "hash": "sha256-YXzj9v7a0buVMm+DZ0DtkScZS/ZbUrHJOt3qcYtnYVY=",
      "url": "_framework/System.Runtime.Handles.fg5kz6lkg1.wasm"
    },
    {
      "hash": "sha256-THDhGf9BCrSJ9Dc4HuyDmNhbdBrcxGQkVTrjqgSlJ5Y=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.wts7elsoj1.wasm"
    },
    {
      "hash": "sha256-KOSatT2XMoxuYPGOcEkfLE2IpYnEDNxRKWjtbtNoEk0=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.wikdnhmugy.wasm"
    },
    {
      "hash": "sha256-MPwfthOtcSQtbc/cQkRvLBNai04LM6OrplBwd7QEVx0=",
      "url": "_framework/System.Runtime.InteropServices.k720ljpkms.wasm"
    },
    {
      "hash": "sha256-NOpY3AgcjrPBOsaSW1QkhhgP3Kvxnf9fssCYKj5jF+0=",
      "url": "_framework/System.Runtime.Intrinsics.o9fm7inv0s.wasm"
    },
    {
      "hash": "sha256-vxCtf5sDS2iRg3+5697ErKB9phlMN1qQW7yqx69NLjk=",
      "url": "_framework/System.Runtime.Loader.5z1xrbq3gs.wasm"
    },
    {
      "hash": "sha256-kLp+41MKw6HJWd6tTF6QTSUe/HfRkMrDyYqQkf3E4HU=",
      "url": "_framework/System.Runtime.Numerics.0w7idgmm8c.wasm"
    },
    {
      "hash": "sha256-VsWXsk6PwS0/Bt2eb09pk/bNJWpOnyi2hRbGKimcBVo=",
      "url": "_framework/System.Runtime.Serialization.6caw9o814c.wasm"
    },
    {
      "hash": "sha256-ZGVgADzjjZBikZmXDKy0yg0e0H4itJO4/XpT9AbdCN8=",
      "url": "_framework/System.Runtime.Serialization.Formatters.gphf6qnq65.wasm"
    },
    {
      "hash": "sha256-ivo1Fw+p2RfT8eThu1+WB7L1ndlVFRhbnOPx5jKNaVA=",
      "url": "_framework/System.Runtime.Serialization.Json.uy989eosch.wasm"
    },
    {
      "hash": "sha256-JfbkAYZDOkSt3lg0WyuE0t9CBWqlV2+Sz7IQBG7Yzbw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.3q7zsjzsco.wasm"
    },
    {
      "hash": "sha256-iyVbGnMfkGVjX7fB+votSNmvk5Cdg1c4lhZVX0gk4Ws=",
      "url": "_framework/System.Runtime.Serialization.Xml.fn44d6rik8.wasm"
    },
    {
      "hash": "sha256-ddrVHQAWJ00p0PHXfwp3OJb3O1BO2Fie+YaHJzMzPeQ=",
      "url": "_framework/System.Security.AccessControl.lsn0iceylj.wasm"
    },
    {
      "hash": "sha256-1dJ+cVj/rQQ+kV6HwAdtA5GviyB/KKLkyhyAW2IYjaI=",
      "url": "_framework/System.Security.Claims.tinfecfh1e.wasm"
    },
    {
      "hash": "sha256-+MW/+T6wYCj9GlFr9DjBKjWZLi0jPcZ1M/NlD6PSqPg=",
      "url": "_framework/System.Security.Cryptography.Algorithms.szchu0omsd.wasm"
    },
    {
      "hash": "sha256-fe2mjNvJaNpi4U0yJTxo/QpWJgpFOYP8Cap4hsB2om0=",
      "url": "_framework/System.Security.Cryptography.Cng.tg2su1vayp.wasm"
    },
    {
      "hash": "sha256-bTtmZvfyggr9LLY1sMefJbGCWFYxQ+7pUg1YN/CYBrI=",
      "url": "_framework/System.Security.Cryptography.Csp.vdqwngku20.wasm"
    },
    {
      "hash": "sha256-B7kX2rvGpqfY2RAyR3Xh3x5J1M4foDmfPbTwofzaLQA=",
      "url": "_framework/System.Security.Cryptography.Encoding.tnqstt8i3f.wasm"
    },
    {
      "hash": "sha256-c8HVbnFyhQg3Cm2GbnWLnSVuO1gbkSLMHdlP03TO++M=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.vd4tq7rihd.wasm"
    },
    {
      "hash": "sha256-JPf/vhIAEtp+t6FVYvFTh8SLDgsXK1r8XwI9MFISUro=",
      "url": "_framework/System.Security.Cryptography.Primitives.sio8tbcv7y.wasm"
    },
    {
      "hash": "sha256-ZZ8Ecr63PHOy0BzB2+0w4HRaa4yqeNOj2MuXyBjiM/k=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.vfqfhnkej8.wasm"
    },
    {
      "hash": "sha256-KZrmyjsMG35zXmaE6ja3bAgvlV2yQAhof7b7gEBnrZY=",
      "url": "_framework/System.Security.Cryptography.l5u6gnf096.wasm"
    },
    {
      "hash": "sha256-7Dg5E/Jv0cPLM/oqKmrhCZQuk8o0LWNa8eJQ7JCtGOY=",
      "url": "_framework/System.Security.Principal.8v7pzc6f0d.wasm"
    },
    {
      "hash": "sha256-9/sekOHja++s1vYaDtM6HT0lOJeJyoo32HFdiLurLfM=",
      "url": "_framework/System.Security.Principal.Windows.ldi42vnlz2.wasm"
    },
    {
      "hash": "sha256-IR9DwKehFTc4AA1gM55e136hedy52EntxeZI4S6j6TI=",
      "url": "_framework/System.Security.SecureString.xw0y2dxlhg.wasm"
    },
    {
      "hash": "sha256-03t1x8je5QIU19rEfnEsBqUbj2Azcg1E4phQkfXC2UA=",
      "url": "_framework/System.Security.fl5q9pzcow.wasm"
    },
    {
      "hash": "sha256-6c3PdGeNbXjQvdEOjnNhyB7hx6ti5dO5lOcgQB4ebWM=",
      "url": "_framework/System.ServiceModel.Web.nk3wk16ns8.wasm"
    },
    {
      "hash": "sha256-0A7zR9riAw51MjVpAtACWjHLfXfdJyF6KykKisSIUx0=",
      "url": "_framework/System.ServiceProcess.4n5pile68t.wasm"
    },
    {
      "hash": "sha256-B1yymCKqgbZ9zbCyB/W9ocbiV3wdl4+gRJItY2umDSc=",
      "url": "_framework/System.Text.Encoding.7kzst7stdn.wasm"
    },
    {
      "hash": "sha256-jrT08/NjUv6+v0QZvlXVgYQVnMoHa7s1GdZdaBXW5Y4=",
      "url": "_framework/System.Text.Encoding.CodePages.ykcj58k0je.wasm"
    },
    {
      "hash": "sha256-ay1hiCOn7mQBiUx1EMkcC92PfuWozE7fZnUzpriCU/s=",
      "url": "_framework/System.Text.Encoding.Extensions.nlydxjh19m.wasm"
    },
    {
      "hash": "sha256-VNMxVpfZKD7wg/4o2z+8xT4gLGCwu967evaVA2zsoMs=",
      "url": "_framework/System.Text.Encodings.Web.grd8pnwzq5.wasm"
    },
    {
      "hash": "sha256-NR8eOBenFgH0oaEXT8zDpgAEqtNlpnM4orufS8CHdtk=",
      "url": "_framework/System.Text.Json.j2r3lclw18.wasm"
    },
    {
      "hash": "sha256-FAZui2n1Y5pZx16yb867GHgo/Ml9aNjvdkZLyB1KphE=",
      "url": "_framework/System.Text.RegularExpressions.gtbtxpqvsh.wasm"
    },
    {
      "hash": "sha256-Zs1dyDHECsvmoSvywTXACBabgK0uR6YeOqdkpU24O2g=",
      "url": "_framework/System.Threading.Channels.6ly6a97nsg.wasm"
    },
    {
      "hash": "sha256-Yx1D0yUjr5Ibvl/nAHTJaa1b4rflinXkM9KFQG/SCPI=",
      "url": "_framework/System.Threading.Overlapped.vhe0cauobg.wasm"
    },
    {
      "hash": "sha256-GoERtTKb8W4nbZT93d+optrQ/Jv4f9pU7acTQqHdAAY=",
      "url": "_framework/System.Threading.Tasks.Dataflow.uf2vj8lolq.wasm"
    },
    {
      "hash": "sha256-tLB6J6lcWykITLdTrLINFi7VE5h/Bn2eTFp+3uegOfU=",
      "url": "_framework/System.Threading.Tasks.Extensions.ovsq4u2j97.wasm"
    },
    {
      "hash": "sha256-PahrtXZJtg7x92RDZD9pvhQ7F6YFhcsTSvT2dVnFIlk=",
      "url": "_framework/System.Threading.Tasks.Parallel.buo4hciu3w.wasm"
    },
    {
      "hash": "sha256-obzl5Tr7ZUGu67PhpP/RMSaAY32BgeQWfH/eS7FDjWE=",
      "url": "_framework/System.Threading.Tasks.fc2uoh6qo1.wasm"
    },
    {
      "hash": "sha256-Gtq5BMvRXZSd5+cE2kyk3DYdB0uo6/imn62TkihOZKE=",
      "url": "_framework/System.Threading.Thread.i99sw2awmh.wasm"
    },
    {
      "hash": "sha256-/jvTucP+IWJae0S/CvCbzD0GaCVLM760MT3wn72Lfxw=",
      "url": "_framework/System.Threading.ThreadPool.ecwhyvkgk4.wasm"
    },
    {
      "hash": "sha256-FfINM96F2KImaKIYqhW2w7r9/u/jsnbUSFa165DDIyk=",
      "url": "_framework/System.Threading.Timer.l8u4gk6tg9.wasm"
    },
    {
      "hash": "sha256-LQZlRm8cnSqcm1QEwGnlPNQEVCIMyV95fJsOlkHBmys=",
      "url": "_framework/System.Threading.nv6otxy934.wasm"
    },
    {
      "hash": "sha256-jGyUOQAnrafqUe5niexxQR2wstiW0gBGGFYckwQK/JE=",
      "url": "_framework/System.Transactions.Local.cqwzbi5tww.wasm"
    },
    {
      "hash": "sha256-uvgal4WJlrbNHkH3qlpImGCBBcsV7lDZPJvdvAnwyB0=",
      "url": "_framework/System.Transactions.eqportussb.wasm"
    },
    {
      "hash": "sha256-R3p8pi/HWtl9kfrDQXD4pEqpToJzP2gJ69gqQ/8QKJA=",
      "url": "_framework/System.ValueTuple.3p8lz2dxdg.wasm"
    },
    {
      "hash": "sha256-yfTTxrpMsBiv1gn4v6yvpQ9E0mLSmi7e2euKYUxgYsU=",
      "url": "_framework/System.Web.HttpUtility.jd5wcr9biz.wasm"
    },
    {
      "hash": "sha256-bLW+BZY37sNHkwv69/ELB+Zoq4iO2NLaUkPlMhV8SR4=",
      "url": "_framework/System.Web.w3ew2t5qa6.wasm"
    },
    {
      "hash": "sha256-K/zEg/9klhrZ41iV2xiuvTZBHYlsKOVsh7B9N/7Aes0=",
      "url": "_framework/System.Windows.tativ8o637.wasm"
    },
    {
      "hash": "sha256-5E+X6Q2jjx0HMS7fid3goSnVX07vecUwgtPRv1si72Q=",
      "url": "_framework/System.Xml.Linq.wpsaw4fs0c.wasm"
    },
    {
      "hash": "sha256-4yv0OjkHh4LeWTiszAl0XyizoJzQMAoSWQaDVI+oif0=",
      "url": "_framework/System.Xml.ReaderWriter.lis3h0bjpq.wasm"
    },
    {
      "hash": "sha256-sWgN6Xgjze65u1ycVgaDsiWJdNlZUx9+JTcL9WwDcyA=",
      "url": "_framework/System.Xml.Serialization.b9gojf6ll8.wasm"
    },
    {
      "hash": "sha256-k0ZdE8i4+oAvcp6jWVX3xoUYtN5RLfO81xuOWr54M6c=",
      "url": "_framework/System.Xml.XDocument.jcxbdnyj8b.wasm"
    },
    {
      "hash": "sha256-cWjP7jmVquElgreFLhiAm8vhCd04AHijbNygZ4Mirvs=",
      "url": "_framework/System.Xml.XPath.1c8x86y34z.wasm"
    },
    {
      "hash": "sha256-kbIw5/HD14mnsaE7eTZ8Xoq7e0PKtHerEoo4q4JkrJM=",
      "url": "_framework/System.Xml.XPath.XDocument.vwdo924nyz.wasm"
    },
    {
      "hash": "sha256-a/xFP8QQMenKlKQuMLH7plGmG3Fa/y52SdXyJewxvag=",
      "url": "_framework/System.Xml.XmlDocument.hh2c0bum76.wasm"
    },
    {
      "hash": "sha256-TU4cHD6oH8UiQaFcbxLNXMt8JZT/mQ34Y7ECuQf+qaI=",
      "url": "_framework/System.Xml.XmlSerializer.php9d66sr9.wasm"
    },
    {
      "hash": "sha256-x1ntQJC4IY+c2WAfQAc7iBKmWcPmwBgUFWymwEW0ZTE=",
      "url": "_framework/System.Xml.lt9uhmpnr1.wasm"
    },
    {
      "hash": "sha256-ws3zoKLV/3tSYvSoxCHWv6IElcq4VpyT0p12ik3rw8I=",
      "url": "_framework/System.quncyez9vs.wasm"
    },
    {
      "hash": "sha256-7LCr4nX9JSGuwzMr8Rk8TGvC6ApzQNxCDiMV/0I9JlI=",
      "url": "_framework/WindowsBase.ovqw333kan.wasm"
    },
    {
      "hash": "sha256-iCp1kvqiS/PZIeSIjvwnQxx+xWQnXUO7u0zVRKW9VO4=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-zoGTv1THI1ohU8YlTf4/31t+nriX3EIuBnVSnf1wrXY=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-WIUiy49hHQ3kOAtRdCtUzm3Yg5BnOqCC+Q+kri9Fi1g=",
      "url": "_framework/dotnet.native.8o8n7iomrf.js"
    },
    {
      "hash": "sha256-bvHGVH9zAMOjdIvgvRKP4Bg793vWpedEYSWg32uUr3o=",
      "url": "_framework/dotnet.native.aep4lch3d1.wasm"
    },
    {
      "hash": "sha256-q/nr9rL9/qurnmyljWmcv7yStKuvDUHexkNvaRJ3cD0=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-jZgH0LixLeQKqaq33akQgDGhfE7vbXbHtvCId5HC0Yo=",
      "url": "_framework/mscorlib.l6md3pggqy.wasm"
    },
    {
      "hash": "sha256-DeeBl9s8G34N3IfYRQ+MoY807amodj8cvpuvUSNaWE4=",
      "url": "_framework/netstandard.lij9csiyuf.wasm"
    },
    {
      "hash": "sha256-dAp0wMP7tRneETcXdRF5KYeaO/0VTG861v1Dm09lTz4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-vGouo/eeVI6KmA7jNH7bmsJZ63vD6N9fl0KmkG/mVEg=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-X2ncdkhTVjsHaFO7m9+uPsG6OF/qX59I3mXhF9qs89I=",
      "url": "images/dima.png"
    },
    {
      "hash": "sha256-49XGfwW7cFuQoqcDEp+/ePQYKCMc+z257Ql0e93Jfy4=",
      "url": "images/logo.png"
    },
    {
      "hash": "sha256-nAqPeNO1XZArIXT3df5ujtR/v6fGsPVz8zL+voW2y8c=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-RyuzmxKakQdeHwGfR/z1CYPVcIvuMjyccGCmSXKF+00=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-pD/rhfAIgIQp7+FpKKVWE/6a7n5nG2wodAUxMEKH+yc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-j+Ee7B5PFdAh/IOqBpQ3VbaQASUOg3leLOpnv0mvvr4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-52JjQyh9tUg0cUcG9C5GeV3j+O+JxpSZew81BxavFcs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-UZafZ0ArbQZLb8wrazTv9Wqvw/wQxdjhNeA1JdaT3do=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-hzlFAU1ZkyxoRoNqQFKtFzLinuPL2I4LJHI9v8MbEnE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-7a+SMyJcO2/pKegsJ/ReTdyJiRYh5yeCpCk4SMzYBLw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-NDRksNibo5CKxpMYJuKwP5hcGYvFrGiCF+/rGSKyw7M=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-20pNZ3A0y452+2gfm7pWCnfBh6C0r4W8U6DLhEkIPs4=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-7ieZghAMBTZNOZQm4cK05a3b54keIzxJI3FcQwZhfH8=",
      "url": "manifest.webmanifest"
    }
  ]
};
